<!-- _coverpage.md -->

![logo](_media/icon.svg ':size=180x180')

# 疏记 <small>V0.1</small>

> 一个乱七八糟记录的文档站

- 基于docsify，部署于vercel，he.net提供域名解析
- 全文markdown写作，轻便快捷
- 个人记录，没有体系没有水平

[GitHub](https://github.com/realzsy/docsify/)
[Get Started](README.md)